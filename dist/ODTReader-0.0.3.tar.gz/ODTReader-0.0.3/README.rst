# ODTReader
Lightweight python module to allow extracting text from OpenDocument (odt) files.
